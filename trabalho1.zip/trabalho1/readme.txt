o input deve ser feito da seguinte forma:

a configuração inicial e fnal deve ser impresso da seguinte formaem duas linhas:

a b c d e f g h i j k l m n o p
0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 0

Após isto pergunta-se qual método de procura selecionado:

1.DFS
2.BFS
3.IDFS
4.Guloso
5.A*

Após estas definições, será impresso:
.A resposta
.Espaço de memória criado
.Porfundidade
.Tempo de execução