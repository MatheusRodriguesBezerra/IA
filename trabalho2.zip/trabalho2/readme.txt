Para rodar, basta ter o python instalado na máquina.
Aceder ao cmd na pasta onde se encontra o arquivo main.py e rodar:

python main.py

Divirta-se :)